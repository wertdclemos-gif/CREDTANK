-- CredTank - registry de maquininhas
-- A aplicação executa essa migração automaticamente via api/bootstrap.php.
-- Este arquivo serve apenas para conferência/manualização na Hostinger.

CREATE TABLE IF NOT EXISTS app_devices (
  device_id VARCHAR(64) NOT NULL PRIMARY KEY,
  posto_id VARCHAR(40) NOT NULL,
  nome VARCHAR(190) NOT NULL,
  codigo_maquininha VARCHAR(80) DEFAULT NULL,
  codigo_acesso VARCHAR(190) DEFAULT NULL,
  token_hash VARCHAR(255) NOT NULL DEFAULT '',
  status VARCHAR(20) NOT NULL DEFAULT 'ativo',
  user_agent VARCHAR(500) DEFAULT NULL,
  activated_at DATETIME DEFAULT NULL,
  last_seen_at DATETIME DEFAULT NULL,
  blocked_at DATETIME DEFAULT NULL,
  payload LONGTEXT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_devices_posto (posto_id),
  KEY idx_devices_codigo (codigo_maquininha),
  KEY idx_devices_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
