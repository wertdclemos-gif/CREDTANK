<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/bootstrap.php';

function tx_json_flags(): int
{
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    return $flags;
}

function tx_normalize_list($value): array
{
    return is_array($value) ? array_values(array_filter($value, 'is_array')) : [];
}

function tx_normalize_timestamp($value): string
{
    if ($value instanceof DateTimeInterface) {
        return $value->format(DATE_ATOM);
    }
    if (is_numeric($value)) {
        $number = (float) $value;
        if ($number > 1000000000000) {
            $number /= 1000;
        }
        try {
            return (new DateTimeImmutable('@' . (int) $number))
                ->setTimezone(new DateTimeZone(date_default_timezone_get()))
                ->format(DATE_ATOM);
        } catch (Throwable $e) {
        }
    }
    $raw = trim((string) $value);
    if ($raw !== '') {
        try {
            return (new DateTimeImmutable($raw))->format(DATE_ATOM);
        } catch (Throwable $e) {
        }
    }
    return (new DateTimeImmutable())->format(DATE_ATOM);
}

function tx_mysql_datetime($value): string
{
    try {
        return (new DateTimeImmutable(tx_normalize_timestamp($value)))->format('Y-m-d H:i:s');
    } catch (Throwable $e) {
        return (new DateTimeImmutable())->format('Y-m-d H:i:s');
    }
}

function tx_load_app_state(PDO $pdo): array
{
    $stmt = $pdo->query('SELECT data FROM app_state WHERE id = 1');
    $row = $stmt->fetch();
    if (!$row) {
        return [];
    }
    $decoded = json_decode((string) ($row['data'] ?? ''), true);
    return is_array($decoded) ? $decoded : [];
}

function tx_find_entity(array $list, string $id): ?array
{
    foreach (tx_normalize_list($list) as $entry) {
        if ((string) ($entry['id'] ?? '') === $id) {
            return $entry;
        }
    }
    return null;
}

function tx_fetch_by_id(PDO $pdo, string $transactionId): ?array
{
    $stmt = $pdo->prepare(
        'SELECT transacao_id, funcionario_id, empresa_id, posto_id, combustivel,
                valor, status, data_hora, payload, criado_em, atualizado_em
           FROM transacoes
          WHERE transacao_id = ?
          LIMIT 1'
    );
    $stmt->execute([$transactionId]);
    $row = $stmt->fetch();
    if (!$row) {
        return null;
    }

    $payload = json_decode((string) ($row['payload'] ?? ''), true);
    if (!is_array($payload)) {
        $payload = [];
    }

    $payload['id'] = (string) ($row['transacao_id'] ?? $payload['id'] ?? '');
    $payload['funcionarioId'] = (string) ($row['funcionario_id'] ?? $payload['funcionarioId'] ?? '');
    $payload['empresaId'] = (string) ($row['empresa_id'] ?? $payload['empresaId'] ?? '');
    $payload['postoId'] = (string) ($row['posto_id'] ?? $payload['postoId'] ?? '');
    $payload['combustivel'] = trim((string) ($row['combustivel'] ?? $payload['combustivel'] ?? ''));
    $payload['valor'] = (float) ($row['valor'] ?? $payload['valor'] ?? 0);
    $payload['status'] = (string) ($row['status'] ?? $payload['status'] ?? 'pendente_confirmacao');
    $payload['timestamp'] = tx_normalize_timestamp($payload['timestamp'] ?? $row['data_hora'] ?? null);
    $payload['criadoEmBanco'] = (string) ($row['criado_em'] ?? '');
    $payload['atualizadoEmBanco'] = (string) ($row['atualizado_em'] ?? '');

    return $payload;
}

function tx_same_identity(array $existing, array $incoming): bool
{
    $sameValue = abs((float) ($existing['valor'] ?? 0) - (float) ($incoming['valor'] ?? 0)) < 0.00001;
    return
        (string) ($existing['funcionarioId'] ?? '') === (string) ($incoming['funcionarioId'] ?? '') &&
        (string) ($existing['empresaId'] ?? '') === (string) ($incoming['empresaId'] ?? '') &&
        (string) ($existing['postoId'] ?? '') === (string) ($incoming['postoId'] ?? '') &&
        $sameValue;
}

try {
    $pdo = db_connect();
    ensure_tables($pdo);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'db_unavailable']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $transactionId = trim((string) ($_GET['id'] ?? ''));
    if ($transactionId !== '') {
        $tx = tx_fetch_by_id($pdo, $transactionId);
        if ($tx === null) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'error' => 'transaction_not_found']);
            exit;
        }
        echo json_encode(['ok' => true, 'transaction' => $tx]);
        exit;
    }

    $stmt = $pdo->query(
        "SELECT transacao_id, funcionario_id, empresa_id, posto_id, combustivel,
                valor, status, data_hora, payload, criado_em, atualizado_em
           FROM transacoes
          WHERE status <> 'excluida_admin'
          ORDER BY data_hora DESC, id DESC"
    );
    $rows = $stmt->fetchAll() ?: [];
    $items = [];
    foreach ($rows as $row) {
        $id = (string) ($row['transacao_id'] ?? '');
        if ($id === '') {
            continue;
        }
        $tx = tx_fetch_by_id($pdo, $id);
        if ($tx !== null) {
            $items[] = $tx;
        }
    }
    echo json_encode(['ok' => true, 'transactions' => $items]);
    exit;
}

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'method_not_allowed']);
    exit;
}

$raw = file_get_contents('php://input') ?: '';
$body = json_decode($raw, true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'invalid_json']);
    exit;
}

$action = strtolower(trim((string) ($body['action'] ?? '')));

if ($action === 'create') {
    $tx = $body['transaction'] ?? null;
    if (!is_array($tx)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'invalid_transaction']);
        exit;
    }

    $transactionId = trim((string) ($tx['id'] ?? ''));
    $funcionarioId = trim((string) ($tx['funcionarioId'] ?? ''));
    $empresaId = trim((string) ($tx['empresaId'] ?? ''));
    $postoId = trim((string) ($tx['postoId'] ?? ''));
    $combustivel = trim((string) ($tx['combustivel'] ?? ''));
    $valor = is_numeric($tx['valor'] ?? null) ? round((float) $tx['valor'], 2) : 0.0;

    if ($transactionId === '' || strlen($transactionId) > 40) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'invalid_transaction_id']);
        exit;
    }
    if ($funcionarioId === '' || $empresaId === '' || $postoId === '' || $valor <= 0) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'invalid_transaction_data']);
        exit;
    }

    $state = tx_load_app_state($pdo);
    $funcionario = tx_find_entity($state['funcionarios'] ?? [], $funcionarioId);
    $empresa = tx_find_entity($state['empresas'] ?? [], $empresaId);
    $posto = tx_find_entity($state['postos'] ?? [], $postoId);

    // Complementa o estado com os registries relacionais caso app_state esteja atrasado.
    if ($funcionario === null) {
        $stmt = $pdo->prepare('SELECT payload FROM app_funcionarios WHERE funcionario_id = ? LIMIT 1');
        $stmt->execute([$funcionarioId]);
        $row = $stmt->fetch();
        if ($row) {
            $decoded = json_decode((string) ($row['payload'] ?? ''), true);
            if (is_array($decoded)) $funcionario = $decoded;
        }
    }
    if ($empresa === null) {
        $stmt = $pdo->prepare('SELECT payload FROM app_empresas WHERE empresa_id = ? LIMIT 1');
        $stmt->execute([$empresaId]);
        $row = $stmt->fetch();
        if ($row) {
            $decoded = json_decode((string) ($row['payload'] ?? ''), true);
            if (is_array($decoded)) $empresa = $decoded;
        }
    }
    if ($posto === null) {
        $stmt = $pdo->prepare('SELECT payload, nome FROM app_devices WHERE posto_id = ? OR device_id = ? LIMIT 1');
        $stmt->execute([$postoId, $postoId]);
        $row = $stmt->fetch();
        if ($row) {
            $decoded = json_decode((string) ($row['payload'] ?? ''), true);
            $posto = is_array($decoded) ? $decoded : ['id' => $postoId, 'nome' => (string) ($row['nome'] ?? 'Posto')];
        }
    }

    if (!is_array($funcionario)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'funcionario_not_found']);
        exit;
    }
    if (array_key_exists('ativo', $funcionario) && !$funcionario['ativo']) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'funcionario_inativo']);
        exit;
    }
    if (!is_array($empresa)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'empresa_not_found']);
        exit;
    }
    if (!is_array($posto)) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'posto_not_found']);
        exit;
    }

    $limiteTransacao = is_numeric($empresa['limiteTransacao'] ?? null)
        ? (float) $empresa['limiteTransacao']
        : 150.0;
    if ($limiteTransacao > 0 && $valor - $limiteTransacao > 0.00001) {
        http_response_code(422);
        echo json_encode([
            'ok' => false,
            'error' => 'transaction_limit_exceeded',
            'limiteTransacao' => round($limiteTransacao, 2),
        ]);
        exit;
    }

    $tx['id'] = $transactionId;
    $tx['funcionarioId'] = $funcionarioId;
    $tx['empresaId'] = $empresaId;
    $tx['postoId'] = $postoId;
    $tx['combustivel'] = $combustivel;
    $tx['valor'] = $valor;
    $tx['status'] = 'pendente_confirmacao';
    $tx['timestamp'] = tx_normalize_timestamp($tx['timestamp'] ?? null);

    // Snapshot histórico gravado na própria transação.
    $tx['funcionarioNome'] = (string) ($tx['funcionarioNome'] ?? $funcionario['nome'] ?? '');
    $tx['funcionarioCpf'] = (string) ($tx['funcionarioCpf'] ?? $funcionario['cpf'] ?? '');
    $tx['funcionarioMatricula'] = (string) ($tx['funcionarioMatricula'] ?? $funcionario['matricula'] ?? '');
    $tx['empresaNome'] = (string) ($tx['empresaNome'] ?? $empresa['nome'] ?? '');
    $tx['empresaCnpj'] = (string) ($tx['empresaCnpj'] ?? $empresa['cnpj'] ?? '');
    $tx['postoNome'] = (string) ($tx['postoNome'] ?? $posto['nome'] ?? '');
    $tx['postoCnpj'] = (string) ($tx['postoCnpj'] ?? $posto['cnpj'] ?? '');
    $tx['postoCidade'] = (string) ($tx['postoCidade'] ?? $posto['cidade'] ?? '');
    $tx['snapshot'] = [
        'funcionario' => [
            'id' => $funcionarioId,
            'nome' => $tx['funcionarioNome'],
            'cpf' => $tx['funcionarioCpf'],
            'matricula' => $tx['funcionarioMatricula'],
        ],
        'empresa' => [
            'id' => $empresaId,
            'nome' => $tx['empresaNome'],
            'cnpj' => $tx['empresaCnpj'],
        ],
        'posto' => [
            'id' => $postoId,
            'nome' => $tx['postoNome'],
            'cnpj' => $tx['postoCnpj'],
            'cidade' => $tx['postoCidade'],
        ],
    ];

    $payload = json_encode($tx, tx_json_flags());
    if ($payload === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'db_encode_failed']);
        exit;
    }

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare(
            'INSERT INTO transacoes
               (transacao_id, funcionario_id, empresa_id, posto_id, combustivel, valor, status, data_hora, payload)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $transactionId,
            $funcionarioId,
            $empresaId,
            $postoId,
            $combustivel !== '' ? $combustivel : null,
            $valor,
            'pendente_confirmacao',
            tx_mysql_datetime($tx['timestamp']),
            $payload,
        ]);
        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();

        // UNIQUE torna a criação idempotente. Se a primeira tentativa foi gravada
        // e apenas a resposta se perdeu na rede, o retry retorna o mesmo registro.
        if ((string) $e->getCode() === '23000') {
            $existing = tx_fetch_by_id($pdo, $transactionId);
            if ($existing !== null && tx_same_identity($existing, $tx)) {
                if ((string) ($existing['status'] ?? '') === 'excluida_admin') {
                    http_response_code(409);
                    echo json_encode([
                        'ok' => false,
                        'transactionSaved' => false,
                        'databaseVerified' => true,
                        'error' => 'transaction_archived_by_admin',
                        'transactionId' => $transactionId,
                    ]);
                    exit;
                }
                echo json_encode([
                    'ok' => true,
                    'transactionSaved' => true,
                    'databaseVerified' => true,
                    'idempotent' => true,
                    'transactionId' => $transactionId,
                    'transaction' => $existing,
                ]);
                exit;
            }
            http_response_code(409);
            echo json_encode(['ok' => false, 'error' => 'duplicate_transaction_id_conflict']);
            exit;
        }

        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'transaction_insert_failed']);
        exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'transaction_insert_failed']);
        exit;
    }

    $saved = tx_fetch_by_id($pdo, $transactionId);
    if ($saved === null || !tx_same_identity($saved, $tx)) {
        http_response_code(500);
        echo json_encode([
            'ok' => false,
            'transactionSaved' => false,
            'databaseVerified' => false,
            'error' => 'transaction_readback_failed',
            'transactionId' => $transactionId,
        ]);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'transactionSaved' => true,
        'databaseVerified' => true,
        'transactionId' => $transactionId,
        'transaction' => $saved,
        'databaseReceipt' => [
            'transactionId' => $transactionId,
            'status' => (string) ($saved['status'] ?? 'pendente_confirmacao'),
            'createdAt' => (string) ($saved['criadoEmBanco'] ?? ''),
        ],
    ]);
    exit;
}

if ($action === 'update_status') {
    $transactionId = trim((string) ($body['transactionId'] ?? ''));
    $status = strtolower(trim((string) ($body['status'] ?? '')));
    $allowed = ['pendente_confirmacao', 'confirmada', 'recusada'];

    if ($transactionId === '' || !in_array($status, $allowed, true)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'invalid_transaction_update']);
        exit;
    }

    $existing = tx_fetch_by_id($pdo, $transactionId);
    if ($existing === null) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'error' => 'transaction_not_found']);
        exit;
    }

    $currentStatus = strtolower(trim((string) ($existing['status'] ?? 'pendente_confirmacao')));
    if (
        in_array($currentStatus, ['confirmada', 'recusada'], true) &&
        $status !== $currentStatus
    ) {
        http_response_code(409);
        echo json_encode(['ok' => false, 'error' => 'invalid_transaction_transition']);
        exit;
    }

    $existing['status'] = $status;
    if ($status === 'confirmada') {
        $existing['confirmadoEm'] = tx_normalize_timestamp($body['confirmadoEm'] ?? $existing['confirmadoEm'] ?? null);
        unset($existing['recusadoEm']);
    } elseif ($status === 'recusada') {
        $existing['recusadoEm'] = tx_normalize_timestamp($body['recusadoEm'] ?? $existing['recusadoEm'] ?? null);
        unset($existing['confirmadoEm']);
    }

    $combustivel = trim((string) ($body['combustivel'] ?? $existing['combustivel'] ?? ''));
    if ($combustivel !== '') {
        $existing['combustivel'] = $combustivel;
    }

    $payload = json_encode($existing, tx_json_flags());
    if ($payload === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'db_encode_failed']);
        exit;
    }

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare(
            "UPDATE transacoes
                SET status = ?,
                    combustivel = ?,
                    payload = ?
              WHERE transacao_id = ?
                AND (status = 'pendente_confirmacao' OR status = ?)"
        );
        $stmt->execute([
            $status,
            $combustivel !== '' ? $combustivel : null,
            $payload,
            $transactionId,
            $status,
        ]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'transaction_update_failed']);
        exit;
    }

    $saved = tx_fetch_by_id($pdo, $transactionId);
    if ($saved === null) {
        http_response_code(500);
        echo json_encode([
            'ok' => false,
            'transactionSaved' => false,
            'databaseVerified' => false,
            'error' => 'transaction_update_readback_failed',
            'transactionId' => $transactionId,
        ]);
        exit;
    }
    if ((string) ($saved['status'] ?? '') !== $status) {
        http_response_code(409);
        echo json_encode([
            'ok' => false,
            'transactionSaved' => false,
            'databaseVerified' => true,
            'error' => 'transaction_status_conflict',
            'transactionId' => $transactionId,
            'currentStatus' => (string) ($saved['status'] ?? ''),
        ]);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'transactionSaved' => true,
        'databaseVerified' => true,
        'transactionId' => $transactionId,
        'transaction' => $saved,
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'invalid_action']);
