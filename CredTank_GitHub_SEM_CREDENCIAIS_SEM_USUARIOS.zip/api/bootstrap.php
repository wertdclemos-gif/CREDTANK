<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

function ensure_tables(PDO $pdo): void
{
    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS app_state (
  id TINYINT UNSIGNED PRIMARY KEY,
  data LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;
    $pdo->exec($sql);

    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS transacoes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  transacao_id VARCHAR(40) NOT NULL UNIQUE,
  funcionario_id VARCHAR(40) NOT NULL,
  empresa_id VARCHAR(40) NOT NULL,
  posto_id VARCHAR(40) NOT NULL,
  combustivel VARCHAR(80) DEFAULT NULL,
  valor DECIMAL(12, 2) NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'pendente_confirmacao',
  data_hora DATETIME NOT NULL,
  payload LONGTEXT NOT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_transacoes_funcionario (funcionario_id),
  KEY idx_transacoes_empresa (empresa_id),
  KEY idx_transacoes_posto (posto_id),
  KEY idx_transacoes_combustivel (combustivel),
  KEY idx_transacoes_data (data_hora)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;
    $pdo->exec($sql);

    // Migra instalacoes anteriores da tabela de transacoes sem apagar dados.
    // O combustivel passa a ter coluna propria para faturamento e relatorios,
    // mantendo tambem o payload JSON por compatibilidade com versoes antigas.
    $transacaoColumns = $pdo->query('SHOW COLUMNS FROM transacoes')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    $combustivelColumnAdded = false;
    if (!in_array('combustivel', $transacaoColumns, true)) {
        $pdo->exec('ALTER TABLE transacoes ADD COLUMN combustivel VARCHAR(80) DEFAULT NULL AFTER posto_id');
        $combustivelColumnAdded = true;
    }
    if (!in_array('status', $transacaoColumns, true)) {
        $pdo->exec("ALTER TABLE transacoes ADD COLUMN status VARCHAR(32) NOT NULL DEFAULT 'pendente_confirmacao' AFTER valor");
    }
    if (!in_array('atualizado_em', $transacaoColumns, true)) {
        $pdo->exec('ALTER TABLE transacoes ADD COLUMN atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER criado_em');
    }
    $transacaoIndexes = $pdo->query('SHOW INDEX FROM transacoes')->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $transacaoIndexNames = array_values(array_unique(array_map(
        static fn(array $row): string => (string) ($row['Key_name'] ?? ''),
        $transacaoIndexes
    )));
    if (!in_array('idx_transacoes_combustivel', $transacaoIndexNames, true)) {
        $pdo->exec('ALTER TABLE transacoes ADD KEY idx_transacoes_combustivel (combustivel)');
    }

    // Recupera o combustivel de transacoes antigas que ja o possuam no payload.
    // A atualizacao e idempotente e nao altera registros que ja possuem valor.
    try {
        if ($combustivelColumnAdded) {
            $pdo->exec(
                "UPDATE transacoes
                    SET combustivel = NULLIF(JSON_UNQUOTE(JSON_EXTRACT(payload, '$.combustivel')), '')
                  WHERE (combustivel IS NULL OR combustivel = '')
                    AND JSON_VALID(payload) = 1
                    AND JSON_EXTRACT(payload, '$.combustivel') IS NOT NULL"
            );
        }
    } catch (Throwable $e) {
        // A aplicacao continua funcionando mesmo em uma versao antiga de MySQL/MariaDB
        // sem suporte completo as funcoes JSON usadas apenas no backfill.
    }

    try {
        $pdo->exec(
            "UPDATE transacoes
                SET status = COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(payload, '$.status')), ''), status)
              WHERE JSON_VALID(payload) = 1
                AND JSON_EXTRACT(payload, '$.status') IS NOT NULL"
        );
    } catch (Throwable $e) {
        // O status continua disponível no payload em versões antigas do banco.
    }

    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS app_empresas (
  empresa_id VARCHAR(40) NOT NULL PRIMARY KEY,
  nome VARCHAR(190) NOT NULL,
  cnpj VARCHAR(30) DEFAULT NULL,
  fechamento VARCHAR(40) DEFAULT NULL,
  limite_mensal DECIMAL(12, 2) NOT NULL DEFAULT 500.00,
  postos_convenio LONGTEXT NOT NULL,
  payload LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;
    $pdo->exec($sql);

    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS app_funcionarios (
  funcionario_id VARCHAR(40) NOT NULL PRIMARY KEY,
  empresa_id VARCHAR(40) NOT NULL,
  nome VARCHAR(190) NOT NULL,
  cpf VARCHAR(30) DEFAULT NULL,
  matricula VARCHAR(60) DEFAULT NULL,
  localidade VARCHAR(190) DEFAULT NULL,
  foto_data MEDIUMTEXT NULL,
  payload LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_app_funcionarios_empresa (empresa_id),
  KEY idx_app_funcionarios_cpf (cpf),
  KEY idx_app_funcionarios_matricula (matricula),
  KEY idx_app_funcionarios_localidade (localidade)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;
    $pdo->exec($sql);

    // Migra instalacoes anteriores de app_funcionarios sem apagar cadastros.
    $funcColumns = $pdo->query('SHOW COLUMNS FROM app_funcionarios')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    if (!in_array('localidade', $funcColumns, true)) {
        $pdo->exec('ALTER TABLE app_funcionarios ADD COLUMN localidade VARCHAR(190) DEFAULT NULL AFTER matricula');
    }
    if (!in_array('foto_data', $funcColumns, true)) {
        $pdo->exec('ALTER TABLE app_funcionarios ADD COLUMN foto_data MEDIUMTEXT NULL AFTER localidade');
    }
    $funcIndexes = $pdo->query('SHOW INDEX FROM app_funcionarios')->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $funcIndexNames = array_values(array_unique(array_map(static fn(array $row): string => (string) ($row['Key_name'] ?? ''), $funcIndexes)));
    if (!in_array('idx_app_funcionarios_localidade', $funcIndexNames, true)) {
        $pdo->exec('ALTER TABLE app_funcionarios ADD KEY idx_app_funcionarios_localidade (localidade)');
    }

    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS app_usuarios (
  user_id VARCHAR(40) NOT NULL PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  cpf VARCHAR(20) DEFAULT NULL,
  role VARCHAR(30) NOT NULL,
  nome VARCHAR(190) NOT NULL,
  senha VARCHAR(190) NOT NULL,
  empresa_id VARCHAR(40) DEFAULT NULL,
  posto_id VARCHAR(40) DEFAULT NULL,
  funcionario_id VARCHAR(40) DEFAULT NULL,
  payload LONGTEXT NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_app_usuarios_email_role (email, role),
  KEY idx_app_usuarios_empresa (empresa_id),
  KEY idx_app_usuarios_cpf (cpf),
  KEY idx_app_usuarios_funcionario (funcionario_id),
  KEY idx_app_usuarios_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;
    $pdo->exec($sql);

    // Migra instalacoes anteriores sem apagar usuarios ja cadastrados.
    $columns = $pdo->query('SHOW COLUMNS FROM app_usuarios')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    if (!in_array('cpf', $columns, true)) {
        $pdo->exec('ALTER TABLE app_usuarios ADD COLUMN cpf VARCHAR(20) DEFAULT NULL AFTER email');
    }
    if (!in_array('funcionario_id', $columns, true)) {
        $pdo->exec('ALTER TABLE app_usuarios ADD COLUMN funcionario_id VARCHAR(40) DEFAULT NULL AFTER posto_id');
    }
    $indexes = $pdo->query('SHOW INDEX FROM app_usuarios')->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $indexNames = array_values(array_unique(array_map(static fn(array $row): string => (string) ($row['Key_name'] ?? ''), $indexes)));
    if (!in_array('idx_app_usuarios_cpf', $indexNames, true)) {
        $pdo->exec('ALTER TABLE app_usuarios ADD KEY idx_app_usuarios_cpf (cpf)');
    }
    if (!in_array('idx_app_usuarios_funcionario', $indexNames, true)) {
        $pdo->exec('ALTER TABLE app_usuarios ADD KEY idx_app_usuarios_funcionario (funcionario_id)');
    }

    // Registry persistente das maquininhas/postos.
    // Mantem compatibilidade com a antiga estrutura app_devices, sem reintroduzir ativacao remota.
    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS app_devices (
  device_id VARCHAR(64) NOT NULL PRIMARY KEY,
  posto_id VARCHAR(40) NOT NULL,
  nome VARCHAR(190) NOT NULL,
  codigo_maquininha VARCHAR(80) DEFAULT NULL,
  codigo_acesso VARCHAR(190) DEFAULT NULL,
  token_hash VARCHAR(255) NOT NULL DEFAULT '',
  status VARCHAR(20) NOT NULL DEFAULT 'ativo',
  user_agent VARCHAR(500) DEFAULT NULL,
  activated_at DATETIME DEFAULT NULL,
  last_seen_at DATETIME DEFAULT NULL,
  blocked_at DATETIME DEFAULT NULL,
  payload LONGTEXT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_devices_posto (posto_id),
  KEY idx_devices_codigo (codigo_maquininha),
  KEY idx_devices_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
SQL;
    $pdo->exec($sql);

    // Migra a tabela app_devices antiga (usada anteriormente para ativacao remota)
    // sem apagar registros nem exigir recriacao manual no painel da Hostinger.
    $deviceColumns = $pdo->query('SHOW COLUMNS FROM app_devices')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    if (!in_array('codigo_maquininha', $deviceColumns, true)) {
        $pdo->exec('ALTER TABLE app_devices ADD COLUMN codigo_maquininha VARCHAR(80) DEFAULT NULL AFTER nome');
    }
    if (!in_array('codigo_acesso', $deviceColumns, true)) {
        $pdo->exec('ALTER TABLE app_devices ADD COLUMN codigo_acesso VARCHAR(190) DEFAULT NULL AFTER codigo_maquininha');
    }
    if (!in_array('payload', $deviceColumns, true)) {
        $pdo->exec('ALTER TABLE app_devices ADD COLUMN payload LONGTEXT NULL AFTER blocked_at');
    }

    $deviceIndexes = $pdo->query('SHOW INDEX FROM app_devices')->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $deviceIndexNames = array_values(array_unique(array_map(
        static fn(array $row): string => (string) ($row['Key_name'] ?? ''),
        $deviceIndexes
    )));
    if (!in_array('idx_devices_codigo', $deviceIndexNames, true)) {
        $pdo->exec('ALTER TABLE app_devices ADD KEY idx_devices_codigo (codigo_maquininha)');
    }

}
