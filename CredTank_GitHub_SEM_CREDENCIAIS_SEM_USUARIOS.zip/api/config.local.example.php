<?php
declare(strict_types=1);
// Copy to config.local.php ONLY on your server, and fill in private values.
define('DB_HOST', '');
define('DB_NAME', '');
define('DB_USER', '');
define('DB_PASS', '');
define('APP_SMTP_HOST', '');
define('APP_SMTP_PORT', '');
define('APP_SMTP_SECURE', '');
define('APP_SMTP_USER', '');
define('APP_SMTP_PASS', '');
define('APP_MAIL_FROM', '');
define('APP_PORTAL_RESET_URL', '');
define('APP_SMS_WEBHOOK_URL', '');
define('APP_SMS_WEBHOOK_TOKEN', '');
