<?php
declare(strict_types=1);

// Private configuration stays on the server and outside version control.
$privateConfig = __DIR__ . '/config.local.php';
if (is_file($privateConfig)) {
    require $privateConfig;
}

if (!defined('DB_HOST')) {
    define('DB_HOST', getenv('DB_HOST') !== false ? (string) getenv('DB_HOST') : 'localhost');
}
if (!defined('DB_NAME')) {
    define('DB_NAME', getenv('DB_NAME') !== false ? (string) getenv('DB_NAME') : '');
}
if (!defined('DB_USER')) {
    define('DB_USER', getenv('DB_USER') !== false ? (string) getenv('DB_USER') : '');
}
if (!defined('DB_PASS')) {
    define('DB_PASS', getenv('DB_PASS') !== false ? (string) getenv('DB_PASS') : '');
}
if (!defined('APP_SMTP_HOST')) {
    define('APP_SMTP_HOST', getenv('APP_SMTP_HOST') !== false ? (string) getenv('APP_SMTP_HOST') : '');
}
if (!defined('APP_SMTP_PORT')) {
    define('APP_SMTP_PORT', getenv('APP_SMTP_PORT') !== false ? (string) getenv('APP_SMTP_PORT') : '587');
}
if (!defined('APP_SMTP_SECURE')) {
    define('APP_SMTP_SECURE', getenv('APP_SMTP_SECURE') !== false ? (string) getenv('APP_SMTP_SECURE') : 'tls');
}
if (!defined('APP_SMTP_USER')) {
    define('APP_SMTP_USER', getenv('APP_SMTP_USER') !== false ? (string) getenv('APP_SMTP_USER') : '');
}
if (!defined('APP_SMTP_PASS')) {
    define('APP_SMTP_PASS', getenv('APP_SMTP_PASS') !== false ? (string) getenv('APP_SMTP_PASS') : '');
}
if (!defined('APP_MAIL_FROM')) {
    define('APP_MAIL_FROM', getenv('APP_MAIL_FROM') !== false ? (string) getenv('APP_MAIL_FROM') : '');
}
if (!defined('APP_PORTAL_RESET_URL')) {
    define('APP_PORTAL_RESET_URL', getenv('APP_PORTAL_RESET_URL') !== false ? (string) getenv('APP_PORTAL_RESET_URL') : '');
}
if (!defined('APP_SMS_WEBHOOK_URL')) {
    define('APP_SMS_WEBHOOK_URL', getenv('APP_SMS_WEBHOOK_URL') !== false ? (string) getenv('APP_SMS_WEBHOOK_URL') : '');
}
if (!defined('APP_SMS_WEBHOOK_TOKEN')) {
    define('APP_SMS_WEBHOOK_TOKEN', getenv('APP_SMS_WEBHOOK_TOKEN') !== false ? (string) getenv('APP_SMS_WEBHOOK_TOKEN') : '');
}
